<?php
$plugin->component = 'block_cocoon_action_panels';  // Recommended since 2.0.2 (MDL-26035). Required since 3.0 (MDL-48494)
$plugin->version = 2021030221.37;
$plugin->requires = 2018051700;
