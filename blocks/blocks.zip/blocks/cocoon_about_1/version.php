<?php
$plugin->component = 'block_cocoon_about_1';
$plugin->version = 2020082613.59;
$plugin->requires = 2018051700;
